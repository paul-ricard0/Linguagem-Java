Um menu básico no qual trabalha com uma tabela no banco de dados, você pode: 
1 - para listar a tabela
2 - para adicionar uma nova linha na tabela
3 - para listar a tabela a por meio do seu titulo
4 - para listar a tabela a por meio da sua categoria
5 - para deletar uma linha na tabela pelo seu id
6 - para finalizar o programa.

